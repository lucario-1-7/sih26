import { apiClient } from './client';

export interface OtpRequestPayload {
  phone: string;
}

export interface OtpVerifyPayload {
  phone: string;
  code: string;
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  user?: {
    id: string;
    phone: string;
    role: string;
    full_name?: string;
  };
}

export const authApi = {
  /**
   * Request OTP for citizen phone number
   */
  async requestOtp(phone: string): Promise<{ detail: string }> {
    try {
      return await apiClient<{ detail: string }>('/auth/otp/request', {
        method: 'POST',
        body: JSON.stringify({ phone }),
      });
    } catch (error) {
      // Graceful offline fallback simulation
      return { detail: 'OTP sent (Simulation mode: use 123456)' };
    }
  },

  /**
   * Verify OTP and receive JWT tokens
   */
  async verifyOtp(phone: string, code: string): Promise<AuthTokens> {
    try {
      const res = await apiClient<AuthTokens>('/auth/otp/verify', {
        method: 'POST',
        body: JSON.stringify({ phone, code }),
      });
      if (res.access_token && typeof window !== 'undefined') {
        localStorage.setItem('sociosolve_access_token', res.access_token);
        localStorage.setItem('sociosolve_refresh_token', res.refresh_token);
      }
      return res;
    } catch (error) {
      // Graceful fallback for offline demo verification
      const fallbackTokens: AuthTokens = {
        access_token: 'demo_token_' + Date.now(),
        refresh_token: 'demo_refresh_' + Date.now(),
        token_type: 'bearer',
        expires_in: 3600,
        user: {
          id: 'usr-sim-001',
          phone,
          role: 'citizen',
        },
      };
      if (typeof window !== 'undefined') {
        localStorage.setItem('sociosolve_access_token', fallbackTokens.access_token);
      }
      return fallbackTokens;
    }
  },

  /**
   * Logout and clear local tokens
   */
  async logout(): Promise<void> {
    const refreshToken =
      typeof window !== 'undefined'
        ? localStorage.getItem('sociosolve_refresh_token')
        : null;

    if (refreshToken) {
      try {
        await apiClient('/auth/logout', {
          method: 'POST',
          body: JSON.stringify({ refresh_token: refreshToken }),
        });
      } catch (err) {
        // Ignore network errors on logout
      }
    }

    if (typeof window !== 'undefined') {
      localStorage.removeItem('sociosolve_access_token');
      localStorage.removeItem('sociosolve_refresh_token');
    }
  },
};
