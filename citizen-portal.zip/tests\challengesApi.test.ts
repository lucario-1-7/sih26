import { describe, it, expect } from 'vitest';
import {
  mapBackendChallengeToProblem,
  challengesApi,
  BackendChallengeResponse,
} from '../src/lib/api/challengesApi';

describe('Challenges API Adapter & Fallback', () => {
  it('should accurately map BackendChallengeResponse to Frontend Problem structure', () => {
    const mockBackendItem: BackendChallengeResponse = {
      id: '550e8400-e29b-41d4-a716-446655440000',
      title: 'Solar Desiccant Dryer Network in Gumla',
      description: 'Lac farmers losing crop value due to post-harvest humidity spikes.',
      status: 'MATCHED',
      severity: 'HIGH',
      submitted_by_id: 'usr-1234',
      administrative_area_id: 'area-9876',
      pin_code: '835207',
      on_behalf_of_name: 'Birsa Munda FPO',
      on_behalf_of_phone: '+91 94311 00000',
      created_at: '2026-02-15T10:00:00Z',
      updated_at: '2026-02-15T10:00:00Z',
    };

    const problem = mapBackendChallengeToProblem(mockBackendItem);

    expect(problem.id).toBe(mockBackendItem.id);
    expect(problem.title).toBe(mockBackendItem.title);
    expect(problem.description).toBe(mockBackendItem.description);
    expect(problem.status).toBe('Matched with Institution');
    expect(problem.trackingCode).toBe('JH-2026-550E');
    expect(problem.submittedBy.fullName).toBe('Birsa Munda FPO');
    expect(problem.milestones).toHaveLength(5);
  });

  it('should gracefully fallback to seed data when backend is offline', async () => {
    const res = await challengesApi.getChallenges();
    expect(res.problems).toBeDefined();
    expect(res.problems.length).toBeGreaterThanOrEqual(10);
  });

  it('should create challenge and return tracking code', async () => {
    const result = await challengesApi.createChallenge({
      title: 'Water filtration in Latehar',
      description: 'High fluoride concentration causing skeletal fluorosis.',
      district: 'Latehar',
      block: 'Netarhat',
      pin_code: '829221',
      category: 'Water Resources',
      fullName: 'Anita Devi',
      phone: '+91 94311 11223',
    });

    expect(result.success).toBe(true);
    expect(result.trackingCode).toMatch(/^JH-2026-\d{3}/);
    expect(result.challenge?.title).toBe('Water filtration in Latehar');
  });
});
