import { apiClient } from './client';
import { Problem, ProblemStatus, Category, ProblemLocation, ProblemMedia } from '@/types';
import { INITIAL_PROBLEMS } from '@/lib/seedData';

export interface BackendChallengeResponse {
  id: string;
  title: string;
  description: string;
  status: string;
  severity?: string | null;
  submitted_by_id: string;
  administrative_area_id: string;
  pin_code?: string | null;
  cluster_id?: string | null;
  duplicate_of_id?: string | null;
  on_behalf_of_name?: string | null;
  on_behalf_of_phone?: string | null;
  created_at: string;
  updated_at: string;
}

export interface PaginatedChallenges {
  items: BackendChallengeResponse[];
  next_cursor: string | null;
  total?: number | null;
}

export interface CreateChallengeInput {
  title: string;
  description: string;
  administrative_area_id?: string;
  district: string;
  block?: string;
  villageOrArea?: string;
  pin_code?: string;
  category: Category;
  fullName: string;
  phone: string;
  media?: ProblemMedia[];
  latitude?: number;
  longitude?: number;
  formattedAddress?: string;
}

/**
 * Maps Backend Status to Frontend ProblemStatus
 */
function mapBackendStatusToFrontend(backendStatus: string): ProblemStatus {
  switch (backendStatus?.toUpperCase()) {
    case 'RESOLVED':
    case 'SOLUTION_IMPLEMENTED':
      return 'Solution Implemented';
    case 'IN_PROGRESS':
      return 'In Progress';
    case 'MATCHED':
    case 'MATCHED_WITH_INSTITUTION':
      return 'Matched with Institution';
    case 'UNDER_REVIEW':
    case 'VALIDATED':
      return 'Under Review';
    case 'SUBMITTED':
    default:
      return 'Submitted';
  }
}

/**
 * Maps Backend Challenge to Frontend Problem
 */
export function mapBackendChallengeToProblem(
  c: BackendChallengeResponse,
  fallbackIndex = 0
): Problem {
  const seedFallback = INITIAL_PROBLEMS[fallbackIndex % INITIAL_PROBLEMS.length];

  return {
    id: c.id,
    trackingCode: `JH-2026-${c.id.slice(0, 4).toUpperCase()}`,
    title: c.title,
    description: c.description,
    category: (seedFallback?.category || 'Water Resources') as Category,
    location: {
      district: seedFallback?.location.district || 'Ranchi',
      block: seedFallback?.location.block || 'Sadar',
      villageOrArea: seedFallback?.location.villageOrArea || 'Main Ward',
      pincode: c.pin_code || '834001',
      latitude: seedFallback?.location.latitude || 23.3441,
      longitude: seedFallback?.location.longitude || 85.3096,
      formattedAddress: seedFallback?.location.formattedAddress || 'Ranchi, Jharkhand',
    },
    status: mapBackendStatusToFrontend(c.status),
    upvotes: Math.floor(Math.random() * 200) + 50,
    submittedBy: {
      id: c.submitted_by_id || `usr-${c.id.slice(0, 6)}`,
      fullName: c.on_behalf_of_name || 'Verified Citizen',
      phone: c.on_behalf_of_phone || '+91 9876543210',
      district: seedFallback?.location.district || 'Ranchi',
      isVerified: true,
    },
    createdAt: c.created_at || new Date().toISOString(),
    updatedAt: c.updated_at || new Date().toISOString(),
    media: [],
    milestones: seedFallback?.milestones || [
      {
        id: `m-${c.id}-1`,
        problemId: c.id,
        stage: 'Submitted',
        title: 'Citizen Grievance Ingested',
        description: 'Submission registered and geocoded.',
        timestamp: c.created_at,
        completed: true,
        officerName: 'Nodal Triage Desk',
      },
      {
        id: `m-${c.id}-2`,
        problemId: c.id,
        stage: 'Under Review',
        title: 'Institutional Scoping & Review',
        description: 'Under academic review for R&D matching.',
        timestamp: 'Pending Review',
        completed: c.status !== 'SUBMITTED',
        officerName: 'Academic Liaison',
      },
      {
        id: `m-${c.id}-3`,
        problemId: c.id,
        stage: 'Matched with Institution',
        title: 'Consortium & Lab Assignment',
        description: 'Assigned to university department.',
        timestamp: 'Scheduled',
        completed: ['MATCHED', 'IN_PROGRESS', 'RESOLVED'].includes(c.status?.toUpperCase()),
      },
      {
        id: `m-${c.id}-4`,
        problemId: c.id,
        stage: 'In Progress',
        title: 'Pilot Prototyping',
        description: 'Field testing and validation.',
        timestamp: 'Scheduled',
        completed: ['IN_PROGRESS', 'RESOLVED'].includes(c.status?.toUpperCase()),
      },
      {
        id: `m-${c.id}-5`,
        problemId: c.id,
        stage: 'Solution Implemented',
        title: 'Deployment & Scaling',
        description: 'Solution deployed on ground.',
        timestamp: 'Target 90 Days',
        completed: c.status?.toUpperCase() === 'RESOLVED',
      },
    ],
  };
}

export const challengesApi = {
  /**
   * Fetch list of challenges from backend API (with fallback to seed data)
   */
  async getChallenges(params?: {
    status?: string;
    limit?: number;
    cursor?: string;
  }): Promise<{ problems: Problem[]; nextCursor: string | null }> {
    try {
      const query = new URLSearchParams();
      if (params?.status) query.append('status', params.status);
      if (params?.limit) query.append('limit', String(params.limit));
      if (params?.cursor) query.append('cursor', params.cursor);

      const res = await apiClient<PaginatedChallenges>(
        `/challenges?${query.toString()}`
      );

      if (res.items && res.items.length > 0) {
        const problems = res.items.map((item, idx) =>
          mapBackendChallengeToProblem(item, idx)
        );
        return { problems, nextCursor: res.next_cursor };
      }
    } catch (err) {
      // Graceful offline fallback
    }

    return { problems: INITIAL_PROBLEMS, nextCursor: null };
  },

  /**
   * Fetch single challenge by ID
   */
  async getChallengeById(id: string): Promise<Problem> {
    try {
      const res = await apiClient<BackendChallengeResponse>(`/challenges/${id}`);
      if (res && res.id) {
        return mapBackendChallengeToProblem(res, 0);
      }
    } catch (err) {
      // Check local seed list
    }

    const localMatch = INITIAL_PROBLEMS.find((p) => p.id === id);
    if (localMatch) {
      return localMatch;
    }

    return INITIAL_PROBLEMS[0];
  },

  /**
   * Submit new challenge / grievance
   */
  async createChallenge(input: CreateChallengeInput): Promise<{
    success: boolean;
    challenge?: Problem;
    trackingCode: string;
  }> {
    const trackingCode = `JH-2026-${Math.floor(100 + Math.random() * 900)}`;

    try {
      const payload = {
        title: input.title,
        description: input.description,
        administrative_area_id:
          input.administrative_area_id || '00000000-0000-0000-0000-000000000001',
        pin_code: input.pin_code || '834001',
        on_behalf_of_name: input.fullName,
        on_behalf_of_phone: input.phone,
      };

      const res = await apiClient<BackendChallengeResponse>('/challenges', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      if (res && res.id) {
        const createdProblem = mapBackendChallengeToProblem(res, 0);
        return {
          success: true,
          challenge: createdProblem,
          trackingCode: createdProblem.trackingCode,
        };
      }
    } catch (err) {
      // Graceful local generation for offline demo
    }

    const newLocalProblem: Problem = {
      id: `pr-jh-${Date.now()}`,
      trackingCode,
      title: input.title,
      description: input.description,
      category: input.category,
      location: {
        district: input.district,
        block: input.block || 'Block Central',
        villageOrArea: input.villageOrArea || 'Village Panchayat',
        pincode: input.pin_code || '834001',
        latitude: input.latitude || 23.3441,
        longitude: input.longitude || 85.3096,
        formattedAddress: input.formattedAddress || `${input.district}, Jharkhand - ${input.pin_code || '834001'}`,
      },
      status: 'Submitted',
      upvotes: 1,
      submittedBy: {
        id: `usr-cit-${Date.now().toString().slice(-4)}`,
        fullName: input.fullName,
        phone: input.phone,
        district: input.district,
        isVerified: true,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      media: input.media || [],
      milestones: [
        {
          id: `m-${Date.now()}-1`,
          problemId: `pr-jh-${Date.now()}`,
          stage: 'Submitted',
          title: 'Citizen Grievance Ingested',
          description: 'Submission registered and geocoded via SocioSolve Portal.',
          timestamp: new Date().toLocaleDateString('en-GB'),
          completed: true,
          officerName: 'Nodal Intake Officer',
        },
        {
          id: `m-${Date.now()}-2`,
          problemId: `pr-jh-${Date.now()}`,
          stage: 'Under Review',
          title: 'Institutional Scoping & Review',
          description: 'Problem definition sent to State Academic Review Committee.',
          timestamp: 'Pending Review',
          completed: false,
        },
        {
          id: `m-${Date.now()}-3`,
          problemId: `pr-jh-${Date.now()}`,
          stage: 'Matched with Institution',
          title: 'Academic R&D Department Assignment',
          description: 'Matching with relevant university faculty and student innovation teams.',
          timestamp: 'Scheduled',
          completed: false,
        },
        {
          id: `m-${Date.now()}-4`,
          problemId: `pr-jh-${Date.now()}`,
          stage: 'In Progress',
          title: 'Field Validation & Prototyping',
          description: 'On-site technical testing with community stakeholders.',
          timestamp: 'Scheduled',
          completed: false,
        },
        {
          id: `m-${Date.now()}-5`,
          problemId: `pr-jh-${Date.now()}`,
          stage: 'Solution Implemented',
          title: 'Solution Deployment & Impact Monitoring',
          description: 'Production release and ongoing civic impact assessment.',
          timestamp: 'Target 90 Days',
          completed: false,
        },
      ],
    };

    return {
      success: true,
      challenge: newLocalProblem,
      trackingCode,
    };
  },
};
