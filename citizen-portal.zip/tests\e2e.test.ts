import { describe, it, expect, beforeEach } from 'vitest';
import { useAppStore } from '../src/store/useAppStore';
import { translations } from '../src/lib/translations';
import { challengesApi } from '../src/lib/api/challengesApi';

describe('SocioSolve Citizen Portal : End-to-End (E2E) Workflow Suite', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('E2E Flow 1: Full Citizen Grievance Submission to Dashboard Ingestion', async () => {
    // 1. Citizen logs in
    useAppStore.getState().loginUser({
      fullName: 'Sunita Soren',
      phone: '+91 94311 55667',
      age: 28,
      district: 'Dumka',
      pincode: '814101',
    });

    const user = useAppStore.getState().user;
    expect(user).toBeDefined();
    expect(user?.fullName).toBe('Sunita Soren');
    expect(user?.isVerified).toBe(true);

    // 2. Citizen raises a problem / grievance
    const newGrievance = useAppStore.getState().addProblem({
      title: 'Solar Irrigation Pump Failure in Shikaripara',
      category: 'Agriculture',
      description: 'Microgrid inverter burned out during lightning storm; 45 tribal paddy farmers without irrigation.',
      location: {
        district: 'Dumka',
        block: 'Shikaripara',
        villageOrArea: 'Benagaria Village',
        pincode: '814101',
        latitude: 24.2389,
        longitude: 87.4922,
        formattedAddress: 'Shikaripara, Dumka District, Jharkhand - 814101',
      },
      media: [],
    });

    expect(newGrievance.id).toBeDefined();
    expect(newGrievance.trackingCode).toMatch(/^JH-2026-AGR-/);
    expect(newGrievance.status).toBe('Submitted');

    // 3. Problem appears at the top of the repository
    const problems = useAppStore.getState().problems;
    const ingested = problems.find((p) => p.id === newGrievance.id);
    expect(ingested).toBeDefined();
    expect(ingested?.submittedBy.fullName).toBe('Sunita Soren');
  });

  it('E2E Flow 2: Search and Track Grievance by Tracking Code', () => {
    // 1. Submit a grievance
    const problem = useAppStore.getState().addProblem({
      title: 'KGBV STEM Lab Equipment Delivery',
      category: 'Education',
      description: 'Robotics kits required for 120 tribal girl students in Netarhat residential school.',
      location: {
        district: 'Latehar',
        block: 'Netarhat',
        villageOrArea: 'KGBV Campus',
        pincode: '829221',
        latitude: 23.4833,
        longitude: 84.2667,
        formattedAddress: 'Netarhat, Latehar District, Jharkhand',
      },
      media: [],
    });

    const trackingCode = problem.trackingCode;

    // 2. Search by tracking code
    const trackedProblem = useAppStore.getState().getProblemById(trackingCode);
    expect(trackedProblem).toBeDefined();
    expect(trackedProblem?.id).toBe(problem.id);
    expect(trackedProblem?.milestones).toHaveLength(5);
    expect(trackedProblem?.milestones[0].completed).toBe(true);
  });

  it('E2E Flow 3: Community Upvoting with Anti-Spam Single Vote Protection', () => {
    const targetProblemId = 'pr-jh-002';
    const initialCount = useAppStore.getState().problems.find((p) => p.id === targetProblemId)?.upvotes || 0;

    // Citizen upvotes
    const upvoteResult = useAppStore.getState().upvoteProblem(targetProblemId);
    expect(upvoteResult.success).toBe(true);

    const updatedCount = useAppStore.getState().problems.find((p) => p.id === targetProblemId)?.upvotes;
    expect(updatedCount).toBe(initialCount + 1);

    // Duplicate upvote rejected
    const secondUpvoteResult = useAppStore.getState().upvoteProblem(targetProblemId);
    expect(secondUpvoteResult.success).toBe(false);
    expect(useAppStore.getState().problems.find((p) => p.id === targetProblemId)?.upvotes).toBe(initialCount + 1);
  });

  it('E2E Flow 4: Bilingual Localization & Typography Scaling Workflow', () => {
    // Switch to Hindi
    useAppStore.getState().setLanguage('hi');
    const hiText = translations.hi;
    expect(useAppStore.getState().language).toBe('hi');
    expect(hiText.jharkhandGovTitle).toBe('झारखण्ड सरकार');
    expect(hiText.submitProblemBtn).toBe('शिकायत दर्ज करें');

    // Switch back to English
    useAppStore.getState().setLanguage('en');
    const enText = translations.en;
    expect(useAppStore.getState().language).toBe('en');
    expect(enText.jharkhandGovTitle).toBe('Government of Jharkhand');
    expect(enText.submitProblemBtn).toBe('Submit Grievance');

    // Test text scale adjustments
    useAppStore.getState().setTextScale('normal');
    useAppStore.getState().increaseTextScale();
    expect(useAppStore.getState().textScale).toBe('large');
    useAppStore.getState().increaseTextScale();
    expect(useAppStore.getState().textScale).toBe('larger');
  });

  it('E2E Flow 5: District Matrix & Category Filtering Integrity', () => {
    const problems = useAppStore.getState().problems;

    // Filter by district 'Khunti'
    const khuntiProblems = problems.filter((p) =>
      p.location.district.toLowerCase().includes('khunti')
    );
    expect(khuntiProblems.length).toBeGreaterThanOrEqual(1);
    khuntiProblems.forEach((p) => {
      expect(p.location.district.toLowerCase()).toContain('khunti');
    });

    // Filter by category 'Water Resources'
    const waterProblems = problems.filter((p) => p.category === 'Water Resources');
    expect(waterProblems.length).toBeGreaterThanOrEqual(1);
    waterProblems.forEach((p) => {
      expect(p.category).toBe('Water Resources');
    });
  });
});
