'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAppStore } from '@/store/useAppStore';
import { translations } from '@/lib/translations';
import { JHARKHAND_DISTRICTS } from '@/lib/seedData';
import { OfficialLogos } from '@/components/OfficialLogos';
import {
  ShieldCheck,
  Phone,
  KeyRound,
  UserCheck,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Lock,
  RefreshCw
} from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const { language, user, loginUser, showToast } = useAppStore();
  const t = translations[language];

  // Steps: 1: Phone -> 2: OTP -> 3: Full Profile -> Verified
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [phone, setPhone] = useState('9835104221');
  const [otp, setOtp] = useState('');
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState('28');
  const [district, setDistrict] = useState('Ranchi');
  const [pincode, setPincode] = useState('834001');
  
  const [resendTimer, setResendTimer] = useState(30);
  const [isVerifying, setIsVerifying] = useState(false);

  // OTP Countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === 2 && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [step, resendTimer]);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.replace(/\D/g, '').length < 10) {
      showToast('Validation Error', 'Please enter a valid 10-digit Indian mobile number.', 'error');
      return;
    }
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setStep(2);
      setResendTimer(30);
      showToast('OTP Sent', `6-digit verification code sent to +91 ${phone}. Demo OTP: 123456`, 'info');
    }, 600);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 6) {
      showToast('Invalid OTP', 'Please enter the 6-digit verification code.', 'error');
      return;
    }
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setStep(3);
      showToast('Mobile Verified', 'Mobile number verified successfully! Please enter your citizen details.', 'success');
    }, 500);
  };

  const handleCompleteSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      showToast('Name Required', 'Please enter your full name as per official ID.', 'error');
      return;
    }
    const parsedAge = parseInt(age, 10);
    if (isNaN(parsedAge) || parsedAge < 16 || parsedAge > 110) {
      showToast('Invalid Age', 'Please enter a valid age (16+).', 'error');
      return;
    }

    loginUser({
      fullName: fullName.trim(),
      phone: `+91 ${phone.replace(/\D/g, '')}`,
      age: parsedAge,
      district,
      pincode: pincode.trim(),
    });

    showToast('Verification Complete', `Welcome, ${fullName.trim()}! You are verified as a Citizen of India.`, 'success');
    router.push('/dashboard');
  };

  const handleAutoFillOtp = () => {
    setOtp('123456');
  };

  return (
    <div className="min-h-[calc(100vh-140px)] w-full bg-[#FAF8F5] py-10 sm:py-16 px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center">
      <div className="max-w-md w-full">
        
        {/* Top Header Card */}
        <div className="text-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-black tracking-tight">
            {t.loginHeading}
          </h1>
          <p className="text-xs sm:text-sm text-black/75 mt-2 leading-relaxed">
            {t.loginSubheading}
          </p>
        </div>

        {/* If already logged in, show quick proceed banner */}
        {user && (
          <div className="mb-6 bg-white border-2 border-black rounded-2xl p-4 shadow-xs flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold text-sm">
                {user.fullName.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-bold text-black">{user.fullName}</p>
                <p className="text-xs text-black/60 font-mono">{user.phone} • {user.district}</p>
              </div>
            </div>
            <Link
              href="/dashboard"
              className="px-3.5 py-1.5 rounded-full bg-black text-white text-xs font-bold hover:bg-black/80 transition-colors"
            >
              {t.dashboardNav} →
            </Link>
          </div>
        )}

        {/* Stepper Progress Bar */}
        <div className="bg-white border-2 border-black rounded-2xl p-6 sm:p-8 shadow-md">
          
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-black/10">
            <div className={`flex flex-col items-center gap-1 ${step >= 1 ? 'text-black font-bold' : 'text-black/40'}`}>
              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-mono font-bold ${
                step >= 1 ? 'border-black bg-black text-white' : 'border-black/30 bg-white'
              }`}>
                {step > 1 ? <CheckCircle2 className="w-4 h-4 text-white" /> : '1'}
              </div>
              <span className="text-[10px] uppercase tracking-wider">Mobile</span>
            </div>

            <div className={`flex-1 h-0.5 mx-2 ${step >= 2 ? 'bg-black' : 'bg-black/20'}`} />

            <div className={`flex flex-col items-center gap-1 ${step >= 2 ? 'text-black font-bold' : 'text-black/40'}`}>
              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-mono font-bold ${
                step >= 2 ? 'border-black bg-black text-white' : 'border-black/30 bg-white'
              }`}>
                {step > 2 ? <CheckCircle2 className="w-4 h-4 text-white" /> : '2'}
              </div>
              <span className="text-[10px] uppercase tracking-wider">OTP</span>
            </div>

            <div className={`flex-1 h-0.5 mx-2 ${step >= 3 ? 'bg-black' : 'bg-black/20'}`} />

            <div className={`flex flex-col items-center gap-1 ${step >= 3 ? 'text-black font-bold' : 'text-black/40'}`}>
              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-mono font-bold ${
                step >= 3 ? 'border-black bg-black text-white' : 'border-black/30 bg-white'
              }`}>
                3
              </div>
              <span className="text-[10px] uppercase tracking-wider">Details</span>
            </div>
          </div>

          {/* STEP 1: MOBILE NUMBER ENTRY */}
          {step === 1 && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="space-y-1.5">
                <label htmlFor="phoneInput" className="block text-xs font-bold uppercase tracking-wider text-black">
                  {t.mobileNumberLabel}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-black/60 font-mono text-sm font-semibold">
                    +91
                  </div>
                  <input
                    id="phoneInput"
                    type="tel"
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="98351 04221"
                    required
                    className="w-full bg-[#FAF8F5] border-2 border-black rounded-xl pl-14 pr-4 py-3 text-base font-mono font-bold text-black focus:bg-white focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>
                <p className="text-[11px] text-black/60 mt-1">
                  We will send a 6-digit one-time password to verify your Indian mobile number.
                </p>
              </div>

              <button
                type="submit"
                disabled={isVerifying}
                className="w-full bg-black text-white font-bold py-3.5 rounded-xl text-sm hover:bg-black/85 transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-95 disabled:opacity-50"
              >
                {isVerifying ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>{t.sendOtpBtn}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* STEP 2: OTP VERIFICATION */}
          {step === 2 && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="otpInput" className="block text-xs font-bold uppercase tracking-wider text-black">
                    {t.otpLabel}
                  </label>
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="text-xs text-black font-semibold hover:underline"
                  >
                    Change +91 {phone}
                  </button>
                </div>

                <div className="relative">
                  <input
                    id="otpInput"
                    type="text"
                    maxLength={6}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    required
                    className="w-full bg-[#FAF8F5] border-2 border-black rounded-xl px-4 py-3 text-xl font-mono font-bold tracking-[0.4em] text-center text-black focus:bg-white focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>

                {/* Demo Helper Pill */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-black/60 font-mono">{t.mockOtpHelper}</span>
                  <button
                    type="button"
                    onClick={handleAutoFillOtp}
                    className="text-[11px] font-bold text-black bg-[#FAF8F5] border border-black/20 px-2 py-0.5 rounded-md hover:bg-black hover:text-white transition-colors"
                  >
                    {t.autoFillOtp}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-black/70 pt-1">
                {resendTimer > 0 ? (
                  <span>{t.resendOtp} <strong className="font-mono text-black">{resendTimer}s</strong></span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setResendTimer(30);
                      showToast('OTP Resent', 'A new verification code has been dispatched.', 'info');
                    }}
                    className="font-bold text-black hover:underline"
                  >
                    {t.resendNow}
                  </button>
                )}
              </div>

              <button
                type="submit"
                disabled={isVerifying || otp.length < 6}
                className="w-full bg-black text-white font-bold py-3.5 rounded-xl text-sm hover:bg-black/85 transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-95 disabled:opacity-50"
              >
                {isVerifying ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" />
                    <span>{t.verifyOtpBtn}</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* STEP 3: CITIZEN PROFILE DETAILS */}
          {step === 3 && (
            <form onSubmit={handleCompleteSignup} className="space-y-4">
              <div className="space-y-1.5">
                <label htmlFor="fullName" className="block text-xs font-bold uppercase tracking-wider text-black">
                  {t.fullNameLabel} *
                </label>
                <input
                  id="fullName"
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={t.fullNamePlaceholder}
                  required
                  className="w-full bg-[#FAF8F5] border-2 border-black rounded-xl px-4 py-2.5 text-sm font-semibold text-black focus:bg-white focus:outline-none focus:ring-2 focus:ring-black"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label htmlFor="age" className="block text-xs font-bold uppercase tracking-wider text-black">
                    {t.ageLabel} *
                  </label>
                  <input
                    id="age"
                    type="number"
                    min={16}
                    max={120}
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    placeholder={t.agePlaceholder}
                    required
                    className="w-full bg-[#FAF8F5] border-2 border-black rounded-xl px-4 py-2.5 text-sm font-semibold text-black focus:bg-white focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="pincode" className="block text-xs font-bold uppercase tracking-wider text-black">
                    {t.pincodeLabel}
                  </label>
                  <input
                    id="pincode"
                    type="text"
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                    placeholder={t.pincodePlaceholder}
                    className="w-full bg-[#FAF8F5] border-2 border-black rounded-xl px-4 py-2.5 text-sm font-mono font-semibold text-black focus:bg-white focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="district" className="block text-xs font-bold uppercase tracking-wider text-black">
                  {t.districtLabel} *
                </label>
                <select
                  id="district"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full bg-[#FAF8F5] border-2 border-black rounded-xl px-4 py-2.5 text-sm font-semibold text-black focus:bg-white focus:outline-none focus:ring-2 focus:ring-black"
                >
                  {JHARKHAND_DISTRICTS.map((dist) => (
                    <option key={dist} value={dist}>
                      {dist}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 bg-[#FAF8F5] border border-black/20 rounded-xl text-xs text-black/80 flex items-center gap-2 mt-2">
                <Lock className="w-4 h-4 text-black flex-shrink-0" />
                <span>Your citizen credential will be tied to Jharkhand Civic Innovation & Grievance Network.</span>
              </div>

              <button
                type="submit"
                className="w-full bg-black text-white font-bold py-3.5 rounded-xl text-sm hover:bg-black/85 transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-95 mt-2"
              >
                <UserCheck className="w-4 h-4" />
                <span>{t.completeSignupBtn}</span>
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
}
