import { describe, it, expect, beforeEach } from 'vitest';
import { useAppStore } from '../src/store/useAppStore';

describe('AppStore Zustand Store', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('should initialize with default English language and normal text scale', () => {
    const state = useAppStore.getState();
    expect(state.language).toBe('en');
    expect(state.textScale).toBe('normal');
  });

  it('should toggle language between English and Hindi', () => {
    useAppStore.getState().setLanguage('hi');
    expect(useAppStore.getState().language).toBe('hi');

    useAppStore.getState().setLanguage('en');
    expect(useAppStore.getState().language).toBe('en');
  });

  it('should scale text size correctly (increase, decrease, cycle)', () => {
    useAppStore.getState().setTextScale('normal');
    expect(useAppStore.getState().textScale).toBe('normal');

    useAppStore.getState().increaseTextScale();
    expect(useAppStore.getState().textScale).toBe('large');

    useAppStore.getState().increaseTextScale();
    expect(useAppStore.getState().textScale).toBe('larger');

    useAppStore.getState().decreaseTextScale();
    expect(useAppStore.getState().textScale).toBe('large');

    useAppStore.getState().cycleTextScale();
    expect(useAppStore.getState().textScale).toBe('larger');

    useAppStore.getState().cycleTextScale();
    expect(useAppStore.getState().textScale).toBe('normal');
  });

  it('should allow upvoting a problem only once per user', () => {
    const testProblemId = 'pr-jh-005';
    const initialProblem = useAppStore.getState().problems.find((p) => p.id === testProblemId);
    const initialUpvotes = initialProblem?.upvotes || 0;

    // First upvote -> Should succeed
    const res1 = useAppStore.getState().upvoteProblem(testProblemId);
    expect(res1.success).toBe(true);

    const updatedProblem = useAppStore.getState().problems.find((p) => p.id === testProblemId);
    expect(updatedProblem?.upvotes).toBe(initialUpvotes + 1);
    expect(useAppStore.getState().hasUserUpvoted(testProblemId)).toBe(true);

    // Second upvote from same user -> Should fail
    const res2 = useAppStore.getState().upvoteProblem(testProblemId);
    expect(res2.success).toBe(false);
    expect(res2.message).toContain('already upvoted');
  });

  it('should add a new grievance and generate a tracking code', () => {
    const newProblem = useAppStore.getState().addProblem({
      title: 'Water contamination in Kanke block',
      category: 'Water Resources',
      description: 'High iron content in tubewell water affecting 200 households.',
      location: {
        district: 'Ranchi',
        block: 'Kanke',
        villageOrArea: 'Kanke Basti',
        pincode: '834006',
        latitude: 23.4352,
        longitude: 85.3211,
        formattedAddress: 'Kanke Block, Ranchi District, Jharkhand - 834006',
      },
      media: [],
    });

    expect(newProblem).toBeDefined();
    expect(newProblem.id).toMatch(/^pr-jh-/);
    expect(newProblem.trackingCode).toMatch(/^JH-2026-WAT-/);
    expect(newProblem.status).toBe('Submitted');

    const found = useAppStore.getState().getProblemById(newProblem.id);
    expect(found).toBeDefined();
    expect(found?.title).toBe('Water contamination in Kanke block');
  });
});
