import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Problem, User, Language, TextScale, Category, ProblemStatus } from '@/types';
import { INITIAL_PROBLEMS } from '@/lib/seedData';
import { challengesApi } from '@/lib/api/challengesApi';
import { authApi } from '@/lib/api/authApi';

interface ToastState {
  show: boolean;
  title: string;
  message: string;
  type: 'success' | 'info' | 'error';
}

interface AppStore {
  // Localization & Display Settings
  language: Language;
  setLanguage: (lang: Language) => void;
  textScale: TextScale;
  setTextScale: (scale: TextScale) => void;
  cycleTextScale: () => void;
  decreaseTextScale: () => void;
  increaseTextScale: () => void;

  // Authenticated Citizen State
  user: User | null;
  loginUser: (data: { fullName: string; phone: string; age: number; district: string; pincode?: string }) => void;
  logoutUser: () => void;

  // Problem Repository State
  problems: Problem[];
  userUpvotes: Record<string, string[]>; // problemId -> array of user identifiers
  upvoteProblem: (problemId: string) => { success: boolean; message?: string };
  hasUserUpvoted: (problemId: string) => boolean;
  addProblem: (problemData: {
    title: string;
    category: Category;
    description: string;
    location: Problem['location'];
    media: Problem['media'];
  }) => Problem;
  getProblemById: (idOrTrackingCode: string) => Problem | undefined;
  syncLiveChallenges: () => Promise<void>;

  // Global Toast
  toast: ToastState | null;
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'error') => void;
  hideToast: () => void;
}

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // Defaults
      language: 'en',
      setLanguage: (lang) => set({ language: lang }),

      textScale: 'normal',
      setTextScale: (scale) => set({ textScale: scale }),
      cycleTextScale: () => {
        const current = get().textScale;
        const next: TextScale = current === 'normal' ? 'large' : current === 'large' ? 'larger' : 'normal';
        set({ textScale: next });
      },
      decreaseTextScale: () => {
        const current = get().textScale;
        if (current === 'larger') set({ textScale: 'large' });
        else if (current === 'large') set({ textScale: 'normal' });
      },
      increaseTextScale: () => {
        const current = get().textScale;
        if (current === 'normal') set({ textScale: 'large' });
        else if (current === 'large') set({ textScale: 'larger' });
      },

      // Default demo logged-in verified citizen
      user: {
        id: 'usr-cit-108',
        fullName: 'Rajesh Kumar Singh',
        phone: '+91 98351 04221',
        age: 32,
        district: 'Ranchi',
        pincode: '834002',
        isVerified: true,
        createdAt: '2026-01-10T12:00:00Z',
      },

      loginUser: ({ fullName, phone, age, district, pincode }) => {
        const newUser: User = {
          id: `usr-cit-${Date.now().toString().slice(-4)}`,
          fullName,
          phone,
          age,
          district,
          pincode: pincode || '834001',
          isVerified: true,
          createdAt: new Date().toISOString(),
        };
        set({ user: newUser });
      },

      logoutUser: () => {
        authApi.logout();
        set({ user: null });
      },

      // Problem dataset
      problems: INITIAL_PROBLEMS,
      userUpvotes: {
        'pr-jh-001': ['usr-cit-108'],
        'pr-jh-003': ['usr-cit-108'],
      },

      hasUserUpvoted: (problemId: string) => {
        const user = get().user;
        const userId = user ? user.id : 'anonymous-session';
        const upvoters = get().userUpvotes[problemId] || [];
        return upvoters.includes(userId);
      },

      upvoteProblem: (problemId: string) => {
        const user = get().user;
        const userId = user ? user.id : 'anonymous-session';
        const upvotesMap = { ...get().userUpvotes };
        const currentUpvoters = upvotesMap[problemId] || [];

        if (currentUpvoters.includes(userId)) {
          return { success: false, message: 'You have already upvoted this problem.' };
        }

        upvotesMap[problemId] = [...currentUpvoters, userId];

        const updatedProblems = get().problems.map((p) => {
          if (p.id === problemId) {
            return { ...p, upvotes: p.upvotes + 1 };
          }
          return p;
        });

        set({
          userUpvotes: upvotesMap,
          problems: updatedProblems,
        });

        return { success: true };
      },

      addProblem: ({ title, category, description, location, media }) => {
        const user = get().user || {
          id: 'usr-guest',
          fullName: 'Anonymous Citizen',
          phone: '+91 99999 99999',
          district: location.district || 'Ranchi',
          isVerified: false,
        };

        const randomNum = Math.floor(1000 + Math.random() * 9000);
        const categoryCode = category.slice(0, 3).toUpperCase();
        const trackingCode = `JH-2026-${categoryCode}-${randomNum}`;
        const newId = `pr-jh-${Date.now().toString().slice(-6)}`;

        const now = new Date();
        const formattedDate = now.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        });

        const newProblem: Problem = {
          id: newId,
          trackingCode,
          title,
          category,
          description,
          location,
          media,
          status: 'Submitted',
          upvotes: 1,
          submittedBy: {
            id: user.id,
            fullName: user.fullName,
            phone: user.phone,
            district: location.district,
            isVerified: user.isVerified,
          },
          milestones: [
            {
              id: `m-${newId}-1`,
              problemId: newId,
              stage: 'Submitted',
              title: 'Challenge Registered by Citizen',
              description: 'Uploaded with geotagged evidence and registered on State Innovation Portal.',
              timestamp: formattedDate,
              completed: true,
              officerName: `${user.fullName} (Citizen)`,
            },
            {
              id: `m-${newId}-2`,
              problemId: newId,
              stage: 'Under Review',
              title: 'Verification by District Nodal Officer',
              description: 'Scheduled for preliminary feasibility & technical severity audit.',
              timestamp: 'Pending Review (Within 48 Hours)',
              completed: false,
            },
            {
              id: `m-${newId}-3`,
              problemId: newId,
              stage: 'Matched with Institution',
              title: 'Institutional Matching & University Research Call',
              description: 'Will be open for university R&D consortia upon verification.',
              timestamp: 'Scheduled',
              completed: false,
            },
            {
              id: `m-${newId}-4`,
              stage: 'In Progress',
              problemId: newId,
              title: 'Prototype Development & Lab Trials',
              description: 'Awaiting institutional adoption.',
              timestamp: 'Scheduled',
              completed: false,
            },
            {
              id: `m-${newId}-5`,
              stage: 'Solution Implemented',
              problemId: newId,
              title: 'Field Deployment & Community Impact Validation',
              description: 'Awaiting implementation.',
              timestamp: 'Target 90 Days',
              completed: false,
            },
          ],
          createdAt: now.toISOString(),
          updatedAt: now.toISOString(),
        };

        const currentProblems = get().problems;
        const currentUpvotes = { ...get().userUpvotes };
        currentUpvotes[newId] = [user.id];

        set({
          problems: [newProblem, ...currentProblems],
          userUpvotes: currentUpvotes,
        });

        // Trigger backend submission in background
        challengesApi.createChallenge({
          title,
          description,
          district: location.district,
          block: location.block,
          villageOrArea: location.villageOrArea,
          pin_code: location.pincode,
          category,
          fullName: user.fullName,
          phone: user.phone,
          media,
          latitude: location.latitude,
          longitude: location.longitude,
          formattedAddress: location.formattedAddress,
        }).catch(() => {
          // Handled gracefully in offline mode
        });

        return newProblem;
      },

      syncLiveChallenges: async () => {
        try {
          const res = await challengesApi.getChallenges();
          if (res && res.problems && res.problems.length > 0) {
            set({ problems: res.problems });
          }
        } catch (err) {
          // Maintain local store state
        }
      },

      getProblemById: (idOrTrackingCode: string) => {
        return get().problems.find(
          (p) =>
            p.id.toLowerCase() === idOrTrackingCode.toLowerCase() ||
            p.trackingCode.toLowerCase() === idOrTrackingCode.toLowerCase()
        );
      },

      toast: null,
      showToast: (title, message, type = 'success') => {
        set({ toast: { show: true, title, message, type } });
      },
      hideToast: () => set({ toast: null }),
    }),
    {
      name: 'sociosolve-citizen-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        language: state.language,
        textScale: state.textScale,
        user: state.user,
        problems: state.problems,
        userUpvotes: state.userUpvotes,
      }),
    }
  )
);
